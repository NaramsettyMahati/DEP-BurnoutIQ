from flask import Flask, render_template, request
import numpy as np

app = Flask(__name__)

def calculate_productivity(study, focus, sleep, tasks):
    return (study * 0.3 + focus * 0.3 + sleep * 0.2 + tasks * 0.2)

def burnout_level(score):
    if score >= 7:
        return "Low Risk"
    elif score >= 4:
        return "Medium Risk"
    else:
        return "High Risk"

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    if request.method == "POST":
        study = float(request.form["study"])
        focus = float(request.form["focus"])
        sleep = float(request.form["sleep"])
        tasks = float(request.form["tasks"])

        score = calculate_productivity(study, focus, sleep, tasks)
        risk = burnout_level(score)

        result = {"score": round(score, 2), "risk": risk}

    return render_template("index.html", result=result)

if __name__ == "__main__":
    app.run(debug=True)
